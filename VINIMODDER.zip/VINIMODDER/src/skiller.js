const skiller = (prefix) => {
	return `
╔════ ◤ TUÉ BRABO BOT◢
║╔▸〘 TUÉ BRABO〙 
║╠➥  *${prefix}alerta*
║╠➥⚠️ para fazer um alerta
║╠➥  *${prefix}divulgar*
║╠➥⚠️ de aviso de videos
║╠➥  *${prefix}bc*
║╠➥⚠️ fazer tm para  todos os usuários
║╠➥  *${prefix}setprefix*
║╠➥⚠️ mudar o prefixo do bot
║╠➥  *${prefix}hidetag*
║╠➥⚠️ marcação invisível
║╠➥*${prefix}clearall*
║╠➥⚠️ limpar todos os chats
║╠➥*${prefix}delete*
║╠➥⚠️deletar mensagem
║╠➥⚠️antimedia (em manutenção)
║╚▸
╚═══ ◤TUÉ BRABO◢ ` 
}

exports.skiller = skiller