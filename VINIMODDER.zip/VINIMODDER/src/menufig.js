const menufig = (prefix) => {
	return `
╔════ ◤STICKERS◢
║╔▸ 
║╠➥  *${prefix}sticker ou ${prefix}f*
║╠➥⚠️ mande uma foto com legenda ${prefix}f
║╠➥ou marque com ${prefix}f
║╠➥  *${prefix}toimg*
║╠➥⚠️ converte sticker em foto>marque um sticker
║╠➥  *${prefix}attp*
║╠➥⚠️ cria um sticker de texto piscando
║╠➥  *${prefix}EM BREVE*
║╠➥⚠️ ....
║╠➥  *${prefix}autostick* (em manutenção)
║╠➥⚠️ ....
║╚▸
╚═══ ◤TUÉ BRABO◢ ` 
}

exports.menufig = menufig