const ajudantes = () => { 
	return `           
╔════ ◤ TUÉ BRABO◢
║╔▸〘 LOGOS 〙 
║╠➥${prefix}blackpink
║╠➥${prefix}neon
║╠➥${prefix}greenneon
║╠➥${prefix}advanceglow
║╠➥${prefix}futureneon
║╠➥${prefix}sandwriting
║╠➥${prefix}sandsummer
║╠➥${prefix}sandengraved
║╠➥${prefix}metaldark
║╠➥${prefix}neonlight
║╠➥${prefix}holographic
║╠➥${prefix}text1917
║╠➥${prefix}minion
║╠➥${prefix}deluxesilver
║╠➥${prefix}newyearcard
║╠➥${prefix}bloodfrosted
║╠➥${prefix}halloween
║╠➥${prefix}jokerlogo
║╠➥${prefix}fireworksparkle
║╠➥${prefix}natureleaves
║╠➥${prefix}bokeh
║╠➥${prefix}toxic
║╠➥${prefix}strawberry
║╠➥${prefix}box3d
║╠➥${prefix}roadwarning
║╠➥${prefix}breakwall
║╠➥${prefix}icecold
║╠➥${prefix}luxury
║╠➥${prefix}cloud
║╠➥${prefix}summersand
║╠➥${prefix}horrorblood
║╠➥${prefix}thunder
║╠➥${prefix}pornhub
║╠➥${prefix}glitch
║╠➥${prefix}avenger
║╠➥${prefix}space
║╠➥${prefix}ninjalogo
║╠➥${prefix}marvelstudio
║╠➥${prefix}lionlogo
║╠➥${prefix}wolflogo
║╠➥${prefix}steel3d
║╠➥${prefix}wallgravity
║╠➥${prefix}wetglass
║╠➥${prefix}multicolor3d
║╠➥${prefix}watercolor
║╠➥${prefix}luxurygold
║╠➥${prefix}galaxywallpaper
║╠➥${prefix}lighttext
║╠➥${prefix}beautifulflower
║╠➥${prefix}puppycute
║╠➥${prefix}royaltext
║╠➥${prefix}heartshaped
║╠➥${prefix}birthdaycake
║╠➥${prefix}galaxystyle
║╠➥${prefix}hologram3d
║╠➥${prefix}greenneon
║╠➥${prefix}glossychrome
║╠➥${prefix}greenbush
║╠➥${prefix}metallogo
║╠➥${prefix}noeltext
║╠➥${prefix}glittergold
║╠➥${prefix}textcake
║╠➥${prefix}starsnight
║╠➥${prefix}wooden3d
║╠➥${prefix}textbyname
║╠➥${prefix}writegalacy
║╠➥${prefix}galaxybat
║╠➥${prefix}snow3d
║╠➥${prefix}birthdayday
║╠➥${prefix}goldplaybutton
║╠➥${prefix}silverplaybutton
║╠➥${prefix}freefire
║╚════════════
╠════〘 TUÉ BRABO 〙
║╔▸
║╠➥ *dono VINI MODDER (base SKILLER)*
║╠➥ *wa.me/+5581973007985*
║╠➥ *status: ON*
║╠➥ *Caso algum comando pare *
║╠➥ *de funcionar digite*
║╠➥*${prefix}bugreport*
║╚▸
╚═══ ◤TUÉ BRABO◢ ` 
}
exports.ajudantes = ajudantes