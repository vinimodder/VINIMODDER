const plays = (prefix) => {
	return `
╔════ ◤ MÚSICA✗✘◢
║╔▸
║╠➥*${prefix}ytplay
║╠➥⚠️baixa música do yt+vídeo*
║╠➥*${prefix}ytplay2
║╠➥⚠️baixa música do yt+vídeo*
║╠➥ *${prefix}play >mais utilizado*
║╠➥⚠️baixa música do yt
║╠➥ *${prefix}play1 >play reserva*
║╠➥⚠️baixa música do yt
║╠➥ *${prefix}play2 >play reserva*
║╠➥⚠️baixa música do yt
║╠➥ *${prefix}play3 >play reserva*
║╠➥⚠️baixa música do yt
║╠➥ *${prefix}play4 >utilizado com link*
║╠➥⚠️baixa música do yt
║╠➥ *${prefix}play5 >play reserva*
║╠➥⚠️baixa música do yt
║ ╠➥ *${prefix}play7 >play reserva*
║╠➥⚠️baixa música do yt
║╚════════════
╠════〘INFORMAÇÕES〙
║╔▸
║╠➥_os reseva sao caso um_ 
║╠➥_nao funciona ou bug_
║╚▸
╚═══ ◤TUÉ BRABO◢ ` 
}

exports.plays = plays
