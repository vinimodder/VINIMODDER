const jogos = (prefix) => {

	return `
╔════ ◤♚𝙅𝙊𝙂𝙊𝙎♞◢
║╔════════════
║╠⚜️ _*porcentagens*_⚜️
║╠➥*${prefix}%lindo*
║╠➥⚠️quantos % vc e lindo
║╠➥*${prefix}%feio*
║╠➥⚠️quantos % vc e feio
║╠➥*${prefix}%gostoso*
║╠➥⚠️quantos % vc e gostoso
║╠➥*${prefix}%gado*
║╠➥⚠️quantos % vc e gado
║╠➥*${prefix}%gay*
║╠➥⚠️quantos % vc e
║╠➥*${prefix}gay @ >mais recomendado*
║╠➥⚠️quantos % vc e gay
║╚════════════
║╔▸〘 RANKS 〙 
║╠➥*${prefix}gostosas*
║╠➥⚠️rank das mais gostosa do gp
║╠➥*${prefix}casal*
║╠➥⚠️vamo achar um casal
║╠➥*${prefix}abraço*
║╠➥⚠️quem vai se abraçar
║╠➥ *${prefix}gay*
║╠➥⚠️ sera que você e gay
║╠➥ *${prefix}rankgay*
║╠➥⚠️lista dos queima rosca
║╠➥ *${prefix}ranknazista*
║╠➥⚠️lista dos nazista
║╠➥*${prefix}rankgostoso*
║╠➥⚠️lista dos mais gostoso
║╠➥*${prefix}rankfeios*
║╠➥⚠️lista dos mais feios
║╠➥*${prefix}ranklindos*
║╠➥⚠️lista dos mais lindos
║╠➥*${prefix}rankcaco*
║╠➥⚠️ rank dos camaco kk
║╠➥*${prefix}rr*
║╠➥⚠️ roleta russa
║╠➥*${prefix}cassino*
║╠➥⚠️ jogo do cassino simples
║╠➥*${prefix}cassino2*
║╠➥⚠️ cassino para vip
║╠➥*${prefix}dado*
║╠➥⚠️ dado colorido
║╠➥*${prefix}dado2*
║╠➥⚠️ dado clássico
║╠➥*${prefix}dado3*
║╠➥⚠️dado comum
║╠➥*{prefix}cc
║╠➥⚠️cara ou coroa
║╚▸
╚═══ ◤TUÉ BRABO◢`
}

exports.jogos = jogos