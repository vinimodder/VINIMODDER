const help = (prefix) => {
return`
╔════ ◤ TUÉ BRABO◢
║╔════════════
║╠➥wa.me/5581973007985
║╠➥STATUS: ON✓
║╠➥BATERIA 50%🔋
║╠➥*${prefix}dono*
║╠➥*${prefix}owner*
║╠➥*${prefix}bugreport*
║╠➥⚠️Caso encontre erros
║╠➥PREFIX:〘${prefix}〙
║╚════════════
║╔▸〘 MENU 〙 
║╠➥*${prefix}stickermenu*
║╠➥⚠️ menu de criação de stickers
║╠➥*${prefix}plays*
║╠➥⚠️ plays de musica
║╠➥Downloads de audios do YT
║╠➥*${prefix}jogos*
║╠➥⚠️ comandos de jogos 
║╠➥para zoar com amigos.
║╠➥*${prefix}musicmenu* 
║╠➥ ⚠️ musicas
║╠➥*${prefix}rigby*
║╠➥ ⚠️ comandos que so o dono do bot pode usar 
║╠➥*${prefix}logomenu*
║╠➥⚠️faça logos personalizadas
║╠➥*${prefix}moddroid*
║╠➥⚠️ pesquisa apks mod
║╠➥*${prefix}xnxxsearch*
║╠➥⚠️ pesquisa vídeos +18
║╠➥*${prefix}xnxx*
║╠➥⚠️ pesquisa vídeos +18
║╚════════════
╠════〘 INFORMAÇÕES 〙
║╔▸
║╠➥ *dono VINI MODDER (base SKILLER)*
║╠➥ *wa.me/5581973007985*
║╠➥ *status: ON*
║╠➥Caso algum comando pare 
║╠➥de funcionar digite
║╠➥*${prefix}bugreport*
║╚▸
╚═══ ◤TUÉ BRABO◢ ` 
}

exports.help = help