Comandos ☕

$ apt update

$ termux-setup-storage

$ apt upgrade

$ pkg install git

$ git clone https://github.com/lordescreamo/antifakev3

$ cd antifakev3

$ bash install.sh

$ npm start

/Caso o bot cair de um ctrl + c  e coloque estes comandos 👇

$ npm i -g pm2 sh


$ pm2 start index.js


$ pm2 monit


Meu número no whatsapp

+55 27 9852-2393


//Base caus
//Comandos Skiller
